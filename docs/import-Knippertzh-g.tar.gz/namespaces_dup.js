var namespaces_dup =
[
    [ "importcopy", "namespaceimportcopy.html", "namespaceimportcopy" ]
];
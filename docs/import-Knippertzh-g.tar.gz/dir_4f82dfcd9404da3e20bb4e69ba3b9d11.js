var dir_4f82dfcd9404da3e20bb4e69ba3b9d11 =
[
    [ "importcopy.py", "importcopy_8py.html", "importcopy_8py" ]
];
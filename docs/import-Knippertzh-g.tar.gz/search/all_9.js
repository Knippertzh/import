var searchData=
[
  ['send_5fto_5fserver_0',['send_to_server',['../namespaceimportcopy.html#a4e0de389fecaa63edd9eab5f652689c6',1,'importcopy']]],
  ['stats_1',['stats',['../classimportcopy_1_1Report.html#a2dcccc066361977543978be4ddc5a646',1,'importcopy::Report']]]
];

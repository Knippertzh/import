var searchData=
[
  ['refresh_5finterval_0',['refresh_interval',['../classimportcopy_1_1TokenManager.html#adfc61a16a89f49b00767f761f1d25c54',1,'importcopy::TokenManager']]]
];

var searchData=
[
  ['process_5fwebsite_0',['process_website',['../namespaceimportcopy.html#a9ecd19839e084e03d0f109674e7a5180',1,'importcopy']]],
  ['process_5fwebsites_1',['process_websites',['../namespaceimportcopy.html#a5a2541c4fcf7f3c4d91742f684b4b6dd',1,'importcopy']]]
];

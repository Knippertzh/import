var searchData=
[
  ['last_5frefresh_0',['last_refresh',['../classimportcopy_1_1TokenManager.html#a0486dddd8ba4b5c411d779919efbf048',1,'importcopy::TokenManager']]],
  ['level_1',['level',['../namespaceimportcopy.html#ab13e8695cf2118b41b7134e2c5e9e149',1,'importcopy']]]
];

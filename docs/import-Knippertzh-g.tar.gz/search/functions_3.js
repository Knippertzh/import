var searchData=
[
  ['main_0',['main',['../namespaceimportcopy.html#a947b61674a221c558461a2ef2191f506',1,'importcopy']]],
  ['map_5fcompany_5fdata_1',['map_company_data',['../namespaceimportcopy.html#ac54a37f23860048922edd3b6ffd177cb',1,'importcopy']]]
];

var searchData=
[
  ['importcopy_0',['importcopy',['../namespaceimportcopy.html',1,'']]],
  ['importcopy_2epy_1',['importcopy.py',['../importcopy_8py.html',1,'']]]
];

var searchData=
[
  ['refresh_5finterval_0',['refresh_interval',['../classimportcopy_1_1TokenManager.html#adfc61a16a89f49b00767f761f1d25c54',1,'importcopy::TokenManager']]],
  ['refresh_5ftoken_1',['refresh_token',['../classimportcopy_1_1TokenManager.html#aae7ceb3708ee23c30c98d36433869659',1,'importcopy::TokenManager']]],
  ['report_2',['Report',['../classimportcopy_1_1Report.html',1,'importcopy']]]
];

var searchData=
[
  ['update_0',['update',['../classimportcopy_1_1Report.html#a8e5376b421c4a97dc242a254be770cd0',1,'importcopy::Report']]]
];

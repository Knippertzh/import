var searchData=
[
  ['_5f_5finit_5f_5f_0',['__init__',['../classimportcopy_1_1TokenManager.html#ac671133301f43b28935ce6d92aaea7a4',1,'importcopy.TokenManager.__init__()'],['../classimportcopy_1_1Report.html#a3e074dc73fc3936ca8b8c4c760f484ba',1,'importcopy.Report.__init__()']]]
];

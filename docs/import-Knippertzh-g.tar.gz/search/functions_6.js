var searchData=
[
  ['send_5fto_5fserver_0',['send_to_server',['../namespaceimportcopy.html#a4e0de389fecaa63edd9eab5f652689c6',1,'importcopy']]]
];

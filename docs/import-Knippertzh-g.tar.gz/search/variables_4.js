var searchData=
[
  ['stats_0',['stats',['../classimportcopy_1_1Report.html#a2dcccc066361977543978be4ddc5a646',1,'importcopy::Report']]]
];

var searchData=
[
  ['filename_0',['filename',['../namespaceimportcopy.html#a438c73c33617629f793cce08bcd2929b',1,'importcopy']]],
  ['format_1',['format',['../namespaceimportcopy.html#a66dcff916575cf51248e6825968a89f4',1,'importcopy']]]
];

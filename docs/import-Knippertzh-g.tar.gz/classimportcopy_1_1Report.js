var classimportcopy_1_1Report =
[
    [ "__init__", "classimportcopy_1_1Report.html#a3e074dc73fc3936ca8b8c4c760f484ba", null ],
    [ "update", "classimportcopy_1_1Report.html#a8e5376b421c4a97dc242a254be770cd0", null ],
    [ "stats", "classimportcopy_1_1Report.html#a2dcccc066361977543978be4ddc5a646", null ]
];
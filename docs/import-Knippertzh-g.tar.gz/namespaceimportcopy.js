var namespaceimportcopy =
[
    [ "Report", "classimportcopy_1_1Report.html", "classimportcopy_1_1Report" ],
    [ "TokenManager", "classimportcopy_1_1TokenManager.html", "classimportcopy_1_1TokenManager" ],
    [ "call_api", "namespaceimportcopy.html#ab81657dc0f9261f7c83b8b563d8de591", null ],
    [ "clean_domain", "namespaceimportcopy.html#a95db84408e8ab5b62aa84a6495d0b695", null ],
    [ "main", "namespaceimportcopy.html#a947b61674a221c558461a2ef2191f506", null ],
    [ "map_company_data", "namespaceimportcopy.html#ac54a37f23860048922edd3b6ffd177cb", null ],
    [ "process_website", "namespaceimportcopy.html#a9ecd19839e084e03d0f109674e7a5180", null ],
    [ "process_websites", "namespaceimportcopy.html#a5a2541c4fcf7f3c4d91742f684b4b6dd", null ],
    [ "send_to_server", "namespaceimportcopy.html#a4e0de389fecaa63edd9eab5f652689c6", null ],
    [ "CONFIG", "namespaceimportcopy.html#a5ba4eca531aa9f5757f0ddb485f12a99", null ],
    [ "filename", "namespaceimportcopy.html#a438c73c33617629f793cce08bcd2929b", null ],
    [ "format", "namespaceimportcopy.html#a66dcff916575cf51248e6825968a89f4", null ],
    [ "level", "namespaceimportcopy.html#ab13e8695cf2118b41b7134e2c5e9e149", null ]
];